# Randrythm

This is module that provides a randomly chosen rhythm game for rhythm game gamers!

## Installation

Enter the following command in your terminal:

`pip install randrythm`

but if you already have installed the package and you want to get the latest version,
simply run:

`pip install randrythm --force-reinstall`
